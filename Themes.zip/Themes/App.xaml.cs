﻿using ThemingDemo.Themes;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace ThemingDemo
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            ThemeManager.ChangeTheme("Default");//Initialize the Default Theme
            MainPage = new MainPage();
        }
    }
}
