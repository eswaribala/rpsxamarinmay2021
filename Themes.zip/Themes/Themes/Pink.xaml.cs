﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace ThemingDemo.Themes
{
	public partial class Pink : ResourceDictionary
    {
		public Pink()
		{
			InitializeComponent ();
		}
	}
}