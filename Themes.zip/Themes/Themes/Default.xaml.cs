﻿using Xamarin.Forms;
namespace ThemingDemo.Themes
{
	public partial class Default : ResourceDictionary
    {
		public Default ()
		{
			InitializeComponent ();
		}
	}
}